package responsi_123190142;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class InputBarang extends JFrame{
    public String namaB, massaB, hargaB;
    Connector connector = new Connector();
    
    //DEKLARASI KOMPONEN
    JLabel lInputB = new JLabel("Input Barang");

    JLabel lNamaB = new JLabel("Nama Barang");
    final JTextField tfNamaB = new JTextField();
    JLabel lMassaB = new JLabel("Massa (gr)");
    final JTextField tfMassaB = new JTextField();
    JLabel lHargaB = new JLabel("Harga Satuan");
    final JTextField tfHargaB = new JTextField();

    JButton tombolSubmit = new JButton("Submit");
    JButton tombolReset = new JButton("Reset");
    JButton tombolKembali = new JButton("Kembali");

    public InputBarang() {
        setTitle("Input Barang");
        setSize(400, 300);

        //ADD COMPONENT
        setLayout(null);
        add(lInputB);
        add(lNamaB);
        add(lMassaB);
        add(lHargaB);
        add(tfNamaB);
        add(tfMassaB);
        add(tfHargaB);
        add(tombolSubmit);
        add(tombolReset);
        add(tombolKembali);

        //LETAK KOMPONEN
        lInputB.setBounds(150, 20, 80, 20);
        lNamaB.setBounds(10, 45, 80, 20);
        tfNamaB.setBounds(130, 45, 240, 20);
        lMassaB.setBounds(10, 70, 80, 20);
        tfMassaB.setBounds(130, 70, 240, 20);
        lHargaB.setBounds(10, 95, 80, 20);
        tfHargaB.setBounds(130, 95, 240, 20);
        tombolSubmit.setBounds(40, 155, 145, 25);
        tombolReset.setBounds(205, 155, 145, 25);
        tombolKembali.setBounds(10, 200, 360, 20);

        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);
        
        tombolSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                   try {
            String query = "INSERT INTO `barang`(`nama`,`massa`,`harga`) VALUES ('"+getNama()+"','"+getMassa()+"','"+getHarga()+"')";
            
            connector.statement = connector.koneksi.createStatement();
            connector.statement.executeUpdate(query);

            System.out.println("Insert Berhasil");
            JOptionPane.showMessageDialog(null,"Insert Berhasil !!");
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
            }
        });
        
        tombolReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                tfNamaB.setText(null);
                tfMassaB.setText(null);
                tfHargaB.setText(null);
            }
        });
        
        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0)  {
                Menu mm = new Menu();
            }
        });
    }
    
    public String getNama() {
        return tfNamaB.getText();
    }

    public String getMassa() {
        return tfMassaB.getText();
    }

    public String getHarga() {
        return tfHargaB.getText();
    }
    
    public void inputDB(){
        
    }
}
