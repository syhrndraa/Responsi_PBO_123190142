package responsi_123190142;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Connector connector = new Connector();
       Menu menu = new Menu();
    }
    
}
